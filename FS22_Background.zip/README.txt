Hello im gonna show u how to put Background in FS22

Go to Program Files x86 and Find Steam

Go to steamapps and go to common

Go to Farming Simulator 22 Folder and go to shared folder

And move the files inside FS_2009 to The shared folder, And have fun!